# Alter

Run several independent copies of the same Windows app, for example a work Slack and a personal Slack, two Chrome or Discord accounts, or a second Claude desktop. Each copy has its own logins, its own icon and its own taskbar button.

## Use it
1. Unzip anywhere and double-click **Start Alter.cmd**. After the first start you can also open Alter from the Start Menu, and pin it to the taskbar.
2. Click **New copy**, then **Browse** and pick the app's `.exe`.
   Alter picks an isolation mode automatically. You can change the name, add a `.png` icon, and click **Create copy**.
3. Launch the copy from its card (**Launch**), or from its Desktop or Start Menu shortcut (you can pin it to the taskbar too).

**Your copies** shows a card per copy with a coral letter tile (for example `CL2` for "Claude 2", or your own icon if you picked one), whether it's running, and a **Launch** / **Stop** button. The arrow opens the copy's page: its paths, environment, **Edit** and **Delete**.

**Stop** closes the copy's windows like clicking X. If the app keeps running in the system tray, Alter asks before forcing it to close.

Command line works too:
```powershell
.\Alter.ps1 -Name "Chrome Work" -Target "C:\Program Files\Google\Chrome\Application\chrome.exe" -Icon .\work.png
```

## Microsoft Store apps (like Claude)
Store apps can't be started from their install folder (`C:\Program Files\WindowsApps\...`). Pick the app's launch alias in `%LOCALAPPDATA%\Microsoft\WindowsApps` instead, for example `claude-desktop.exe` for Claude. If you pick the real program in `WindowsApps`, Alter switches to its launch alias by itself. Store apps without a launch alias aren't supported.

## How it works
For each copy it creates `%LOCALAPPDATA%\ParallWin\<Name>\` containing:

| File | What it is |
|---|---|
| `<Name>.exe` | Tiny launcher compiled on your PC with the copy's icon |
| `config.txt` | Target, arguments, env vars. Edit it by hand if you like; `{DATA}` = the data folder |
| `data\` | This copy's own profile and settings |

The folder is still called `ParallWin` (Alter's earlier name), so copies made before the rename keep working.

Isolation modes:
- **Chromium**: Chrome/Edge/Brave and Electron apps (VS Code, Slack, Notion, Obsidian, Claude...). Adds `--user-data-dir`, plus `--extensions-dir` for VS Code-style editors.
- **Firefox**: own `-profile` + `-no-remote`.
- **Redirect**: generic; points `APPDATA`/`LOCALAPPDATA` at the copy's folder. Discord also gets `--multi-instance`.
- **None**: just a separate launcher, icon and taskbar button.

**Own taskbar button**: while the app runs, the launcher stays open quietly in the background and gives the app's windows their own taskbar ID, so they get a separate taskbar button. Turn this off if you don't want it.

**App updates**: for apps that install into `app-1.2.3` folders and move to a new one on each update (Discord, Slack and others), the launcher always picks the newest version.

## Limits
- Apps with a hard "only one copy" lock (some games, Spotify, many launchers) will still refuse.
- Separation is per profile, not a security sandbox: every copy can still see your files.
- New unsigned `.exe`s may get a SmartScreen/Defender prompt the first time.
- Needs Windows 10/11 (uses the built-in Windows PowerShell 5.1 and .NET Framework compiler). Nothing to install.

## Files
- `Alter.ps1`: the app.
- `Start Alter.cmd`: opens the Alter window.
- `Test-Alter.ps1`: checks the setup end to end (PowerShell, compiler, a test copy of Chrome/Edge and of VS Code, Slack or Discord) and writes `Test-Alter.log`. Remove its test copies with `-Cleanup`.
- `fonts\`: Rubik, Inter and JetBrains Mono for the window (open-source, see `fonts\FONTS.txt`). Keep this folder next to `Alter.ps1`.
- `logo\`: the Alter logo as SVG, PNG and ICO.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test-Alter.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test-Alter.ps1 -Cleanup
```
